
# coding: utf-8

# In[13]:


for i in range(0, 110, 10) :
    C_pretty = round((i-32) * 5 / 9, 1)
    print("F= " + str(i) + ", C= " + str(C_pretty))

