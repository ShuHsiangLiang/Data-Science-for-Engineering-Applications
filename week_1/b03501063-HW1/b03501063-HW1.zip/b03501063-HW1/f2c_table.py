
# coding: utf-8

# In[39]:


print ("F", "C")
for i in range(0, 110, 10) :
    print (i, (i-32) * 5 / 9)

